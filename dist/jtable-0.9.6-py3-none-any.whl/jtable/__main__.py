#!/usr/bin/env python3
import jtable.jtable

jtable.jtable.main()